//목록으로 이동
document.querySelector('.volun-admain-btu-complaint').addEventListener('click', function() {
    location.href = '/notice/list'; // 목록 페이지로 이동
});
