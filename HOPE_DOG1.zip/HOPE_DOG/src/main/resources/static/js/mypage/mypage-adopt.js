
document.querySelector('#protect-list').addEventListener('click', function() {
    location.href = '/mypage/protect'; // 목록 페이지로 이동
});