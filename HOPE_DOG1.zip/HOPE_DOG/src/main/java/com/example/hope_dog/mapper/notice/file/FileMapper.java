package com.example.hope_dog.mapper.notice.file;

public interface FileMapper {
}
