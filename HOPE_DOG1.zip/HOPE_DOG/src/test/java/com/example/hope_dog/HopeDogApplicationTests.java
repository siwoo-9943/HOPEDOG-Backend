package com.example.hope_dog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HopeDogApplicationTests {

	@Test
	void contextLoads() {
	}

}
