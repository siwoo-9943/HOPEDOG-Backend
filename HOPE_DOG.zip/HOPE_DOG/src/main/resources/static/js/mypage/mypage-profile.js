document.querySelector('#adopt').addEventListener('click', function() {
    location.href = '/mypage/adopt'; // 목록 페이지로 이동
});

document.querySelector('#volunteer').addEventListener('click', function() {
    location.href = '/mypage/volun'; // 목록 페이지로 이동
});

document.querySelector('#posts').addEventListener('click', function() {
    location.href = '/mypage/posts'; // 목록 페이지로 이동
});

document.querySelector('#inbox').addEventListener('click', function() {
    location.href = '/mypage/noteboxReceiveList'; // 목록 페이지로 이동
});
