
document.querySelector('.volun-list').addEventListener('click', function() {
    location.href = '/mypage/volunList'; // 목록 페이지로 이동
});

