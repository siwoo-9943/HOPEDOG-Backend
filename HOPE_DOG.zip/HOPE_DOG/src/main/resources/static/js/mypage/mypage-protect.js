document.querySelector('#adopt').addEventListener('click', function() {
    location.href = '/mypage/adopt'; // 목록 페이지로 이동
});


document.querySelector('#adopt-list').addEventListener('click', function() {
    location.href = '/mypage/adopt'; // 목록 페이지로 이동
});