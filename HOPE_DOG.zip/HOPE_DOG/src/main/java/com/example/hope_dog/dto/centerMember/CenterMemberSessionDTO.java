package com.example.hope_dog.dto.centerMember;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
@NoArgsConstructor
public class CenterMemberSessionDTO {
    private Long centerMemberNo;
    private String centerMemberId;
}
